﻿namespace DiceGame
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gameScoreTextBox = new System.Windows.Forms.TextBox();
            this.totalScoreTextBox = new System.Windows.Forms.TextBox();
            this.die2Box = new System.Windows.Forms.TextBox();
            this.die3Box = new System.Windows.Forms.TextBox();
            this.die1Box = new System.Windows.Forms.TextBox();
            this.triplesTextBox = new System.Windows.Forms.TextBox();
            this.doublesTextBox = new System.Windows.Forms.TextBox();
            this.rollDice = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.endGameMessage = new System.Windows.Forms.Label();
            this.bonusMessage = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // gameScoreTextBox
            // 
            this.gameScoreTextBox.Location = new System.Drawing.Point(408, 406);
            this.gameScoreTextBox.Name = "gameScoreTextBox";
            this.gameScoreTextBox.Size = new System.Drawing.Size(132, 26);
            this.gameScoreTextBox.TabIndex = 0;
            this.gameScoreTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gameScoreTextBox.TextChanged += new System.EventHandler(this.ScoreThisRoll);
            // 
            // totalScoreTextBox
            // 
            this.totalScoreTextBox.Location = new System.Drawing.Point(408, 594);
            this.totalScoreTextBox.Name = "totalScoreTextBox";
            this.totalScoreTextBox.Size = new System.Drawing.Size(130, 26);
            this.totalScoreTextBox.TabIndex = 1;
            this.totalScoreTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.totalScoreTextBox.TextChanged += new System.EventHandler(this.TotalScore);
            // 
            // die2Box
            // 
            this.die2Box.Location = new System.Drawing.Point(411, 113);
            this.die2Box.Name = "die2Box";
            this.die2Box.Size = new System.Drawing.Size(100, 26);
            this.die2Box.TabIndex = 2;
            this.die2Box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // die3Box
            // 
            this.die3Box.Location = new System.Drawing.Point(656, 113);
            this.die3Box.Name = "die3Box";
            this.die3Box.Size = new System.Drawing.Size(100, 26);
            this.die3Box.TabIndex = 3;
            this.die3Box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // die1Box
            // 
            this.die1Box.Location = new System.Drawing.Point(167, 113);
            this.die1Box.Name = "die1Box";
            this.die1Box.Size = new System.Drawing.Size(100, 26);
            this.die1Box.TabIndex = 4;
            this.die1Box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // triplesTextBox
            // 
            this.triplesTextBox.Location = new System.Drawing.Point(656, 266);
            this.triplesTextBox.Name = "triplesTextBox";
            this.triplesTextBox.Size = new System.Drawing.Size(100, 26);
            this.triplesTextBox.TabIndex = 5;
            this.triplesTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.triplesTextBox.TextChanged += new System.EventHandler(this.TriplesBonusPoints);
            // 
            // doublesTextBox
            // 
            this.doublesTextBox.Location = new System.Drawing.Point(167, 266);
            this.doublesTextBox.Name = "doublesTextBox";
            this.doublesTextBox.Size = new System.Drawing.Size(100, 26);
            this.doublesTextBox.TabIndex = 6;
            this.doublesTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.doublesTextBox.TextChanged += new System.EventHandler(this.DoublesBonusPoints);
            // 
            // rollDice
            // 
            this.rollDice.BackColor = System.Drawing.SystemColors.ControlLight;
            this.rollDice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rollDice.Location = new System.Drawing.Point(392, 218);
            this.rollDice.Name = "rollDice";
            this.rollDice.Size = new System.Drawing.Size(148, 84);
            this.rollDice.TabIndex = 7;
            this.rollDice.Text = "Roll Dice";
            this.rollDice.UseVisualStyleBackColor = false;
            this.rollDice.Click += new System.EventHandler(this.RollDiceButton);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(668, 218);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 25);
            this.label1.TabIndex = 8;
            this.label1.Text = "Triples";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(406, 369);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 25);
            this.label2.TabIndex = 9;
            this.label2.Text = "Score This Roll";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(406, 548);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 25);
            this.label3.TabIndex = 10;
            this.label3.Text = "Total Score";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(193, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 25);
            this.label4.TabIndex = 11;
            this.label4.Text = "Die 1";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(440, 81);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 25);
            this.label5.TabIndex = 12;
            this.label5.Text = "Die 2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(682, 81);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 25);
            this.label6.TabIndex = 13;
            this.label6.Text = "Die 3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(181, 224);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 25);
            this.label7.TabIndex = 14;
            this.label7.Text = "Doubles";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // endGameMessage
            // 
            this.endGameMessage.AutoSize = true;
            this.endGameMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.endGameMessage.Location = new System.Drawing.Point(361, 667);
            this.endGameMessage.Name = "endGameMessage";
            this.endGameMessage.Size = new System.Drawing.Size(233, 46);
            this.endGameMessage.TabIndex = 15;
            this.endGameMessage.Text = "Game Over";
            this.endGameMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.endGameMessage.Visible = false;
            this.endGameMessage.Click += new System.EventHandler(this.GameOver);
            // 
            // bonusMessage
            // 
            this.bonusMessage.AutoSize = true;
            this.bonusMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bonusMessage.Location = new System.Drawing.Point(406, 462);
            this.bonusMessage.Name = "bonusMessage";
            this.bonusMessage.Size = new System.Drawing.Size(112, 25);
            this.bonusMessage.TabIndex = 16;
            this.bonusMessage.Text = "output label";
            this.bonusMessage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bonusMessage.Visible = false;
            this.bonusMessage.Click += new System.EventHandler(this.BonusMessage_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(979, 760);
            this.Controls.Add(this.bonusMessage);
            this.Controls.Add(this.endGameMessage);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rollDice);
            this.Controls.Add(this.doublesTextBox);
            this.Controls.Add(this.triplesTextBox);
            this.Controls.Add(this.die1Box);
            this.Controls.Add(this.die3Box);
            this.Controls.Add(this.die2Box);
            this.Controls.Add(this.totalScoreTextBox);
            this.Controls.Add(this.gameScoreTextBox);
            this.Name = "Form1";
            this.Text = "Dice Game";
            this.Load += new System.EventHandler(this.DiceGameWindow);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox gameScoreTextBox;
        private System.Windows.Forms.TextBox totalScoreTextBox;
        private System.Windows.Forms.TextBox die2Box;
        private System.Windows.Forms.TextBox die3Box;
        private System.Windows.Forms.TextBox die1Box;
        private System.Windows.Forms.TextBox triplesTextBox;
        private System.Windows.Forms.TextBox doublesTextBox;
        private System.Windows.Forms.Button rollDice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label endGameMessage;
        private System.Windows.Forms.Label bonusMessage;
    }
}

