﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DiceGame
{
    public partial class Form1 : Form
        {
        
        public static int[] numbersArray = new int[3];
        public static int totalPlusPoints;
        public static int totalGameScore = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void DiceGameWindow(object sender, EventArgs e)
        {

        }

        private void RollDiceButton(object sender, EventArgs e)
        {
            numbersArray = RollDice();
            die1Box.Text = Convert.ToString(numbersArray[0]);
            die2Box.Text = Convert.ToString(numbersArray[1]);
            die3Box.Text = Convert.ToString(numbersArray[2]);

            totalPlusPoints = CalculateScore(numbersArray);
            gameScoreTextBox.Text = totalPlusPoints.ToString();

            if (totalPlusPoints < 25)
            {
                totalGameScore += totalPlusPoints;
                doublesTextBox.Text = "0";
                triplesTextBox.Text = "0";
                bonusMessage.Visible = true;
                bonusMessage.Text = "No Bonus";
            }
            if (totalPlusPoints >= 25 && totalPlusPoints < 50)
            {
                totalGameScore += totalPlusPoints;
                doublesTextBox.Text = "25";
                bonusMessage.Visible = true;
                bonusMessage.Text = "Double: Bonus 25";

            }
            if (totalPlusPoints >= 50)
            {
                totalGameScore += totalPlusPoints;
                triplesTextBox.Text = "50";
                bonusMessage.Visible = true;
                bonusMessage.Text = "Triple: Bonus 50";
            }
            totalScoreTextBox.Text = totalGameScore.ToString();

            if (totalGameScore >= 500)
            {
                rollDice.Visible = false;
                endGameMessage.Visible = true;
            }
        }

        private void ScoreThisRoll(object sender, EventArgs e)
        {

        }

        private void TotalScore(object sender, EventArgs e)
        {

        }
        private void DoublesBonusPoints(object sender, EventArgs e)
        {

        }

        private void TriplesBonusPoints(object sender, EventArgs e)
        {

        }

        private void BonusMessage_Click(object sender, EventArgs e)
        {

        }
        private void GameOver(object sender, EventArgs e)
        {

        }

        private static int[] RollDice()
        {
            int min = 1;
            int max = 7;
            int[] numbers = new int[3];

            Random ranNumberGenerator = new Random();
            numbers[0] = ranNumberGenerator.Next(min, max);
            numbers[1] = ranNumberGenerator.Next(min, max);
            numbers[2] = ranNumberGenerator.Next(min, max);

            return numbers;
        }

        private static int CalculateScore(int[] array)
        {
            int doubleBonus = 25;
            int tripleBonus = 50;
            int arraySum = 0;

            foreach (int item in array)
            {
                arraySum += item;
            }

            if ((array[0] == array[1]) || (array[0] == array[2]) || (array[1] == array[2]))
            {
                arraySum += doubleBonus;

            }
            if ((array[0] == array[1]) && (array[0] == array[2]) && (array[1] == array[2]))
            {
                arraySum += tripleBonus;
            }

            return arraySum;
        }
    }
}
